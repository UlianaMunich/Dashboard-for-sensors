var Config = {
    BOSH_SERVER: 'http://likepro.co/http-bind/',
    PUBSUB_SERVER:  'pubsub.likepro.co',
    PUBSUB_NODE:  'pubsub.sensors',
    MUC_SERVER:   'conference.likepro.co',
    REGISTRIES: ['api/sensors/fake']
}