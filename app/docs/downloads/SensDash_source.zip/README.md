Dashboard that renders charts based on incoming XMPP streams
